#include "Tree.hpp"
#include <stdexcept>
#include <string>

#define CATCH_CONFIG_MAIN
#include "./Catch2-master/single_include/catch2/catch.hpp"

using namespace std;

TEST_CASE("Testing check_duplicate_id function") {
	Tree sample_tree1;
  	sample_tree1.add_operator_node(1, DUMMY_ROOT, Add);
  	sample_tree1.add_operator_node(2, 1, Multiply);
  	sample_tree1.add_operand_node(3, 1, 5);
	REQUIRE(sample_tree1.check_duplicate_id(2) == 1);
	REQUIRE(sample_tree1.check_duplicate_id(3) == 1);
	REQUIRE(sample_tree1.check_duplicate_id(30) == 0);
	}

TEST_CASE("Testing evaluate_tree function") {
	  Tree sample_tree2;
  	  sample_tree2.add_operator_node(1, DUMMY_ROOT, Add);
      sample_tree2.add_operator_node(2, 1, Multiply);
      sample_tree2.add_operand_node(3, 1, 5);
      sample_tree2.add_operand_node(4, 2, 2);
      sample_tree2.add_operand_node(5, 2, 3);
      REQUIRE(sample_tree2.evaluate_tree() == 11);
	}

TEST_CASE("Testing printUserWorkload function") {
	  Tree sample_tree3;
  	  sample_tree3.add_operator_node(1, DUMMY_ROOT, Add);
      sample_tree3.add_operator_node(2, 1, Multiply);
      sample_tree3.add_operand_node(3, 1, 5);
      sample_tree3.add_operand_node(4, 2, 2);
      sample_tree3.add_operand_node(5, 2, 3);
      REQUIRE(sample_tree3.find_index_of_node(4) == 3);	
	}